
#pragma once
#include <vector>
#include <cmath>

class WavetableOsc
{
public:
    void prepare(double sr)
    {
        sampleRate = sr;
        generateTable();
    }

    float process()
    {
        auto value = table[(int)index];
        index += increment;
        if (index >= table.size()) index -= table.size();
        return value;
    }

    void setFrequency(float freq)
    {
        increment = (freq * table.size()) / sampleRate;
    }

private:
    void generateTable()
    {
        table.resize(2048);
        for (int i = 0; i < table.size(); ++i)
            table[i] = std::sin(2.0 * M_PI * i / table.size());
    }

    std::vector<float> table;
    double sampleRate = 44100.0;
    float index = 0.0f;
    float increment = 1.0f;
};
