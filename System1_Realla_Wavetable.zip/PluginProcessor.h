
#pragma once
#include <JuceHeader.h>
#include "WavetableOsc.h"

class System1AudioProcessor : public juce::AudioProcessor
{
public:
    void prepareToPlay (double sampleRate, int) override
    {
        osc.prepare(sampleRate);
        osc.setFrequency(110.0f);
    }

    void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            auto* data = buffer.getWritePointer(ch);
            for (int i = 0; i < buffer.getNumSamples(); ++i)
                data[i] = osc.process() * 0.2f;
        }
    }

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

private:
    WavetableOsc osc;
};
