
#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class WaveDisplay : public juce::Component
{
public:
    void paint(juce::Graphics& g) override
    {
        g.fillAll(juce::Colours::black);
        g.setColour(juce::Colours::cyan);

        juce::Path p;
        p.startNewSubPath(0, getHeight()/2);

        for (int x = 0; x < getWidth(); ++x)
        {
            float y = std::sin((float)x * 0.05f);
            p.lineTo(x, getHeight()/2 + y * 40);
        }

        g.strokePath(p, juce::PathStrokeType(2.0f));
    }
};

class System1AudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    System1AudioProcessorEditor(System1AudioProcessor& p) : AudioProcessorEditor(&p)
    {
        addAndMakeVisible(display);
        setSize(800, 400);
    }

    void resized() override
    {
        display.setBounds(50, 50, 700, 300);
    }

private:
    WaveDisplay display;
};
