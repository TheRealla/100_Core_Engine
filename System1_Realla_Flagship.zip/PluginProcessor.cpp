
#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorEditor* System1AudioProcessor::createEditor()
{
    return new System1AudioProcessorEditor(*this);
}
