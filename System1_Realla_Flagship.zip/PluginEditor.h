
#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class System1AudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    System1AudioProcessorEditor(System1AudioProcessor& p) : AudioProcessorEditor(&p), proc(p)
    {
        addAndMakeVisible(wtSlider);
        wtSlider.setRange(0.0, 1.0);
        wtSlider.onValueChange = [this]() {
            proc.osc1.setWTPosition(wtSlider.getValue());
            proc.osc2.setWTPosition(wtSlider.getValue());
        };

        setSize(900, 500);
    }

    void paint(juce::Graphics& g) override
    {
        g.fillAll(juce::Colours::black);
        g.setColour(juce::Colours::cyan);
        g.setFont(24.0f);
        g.drawText("SYSTEM-1 REALLA FLAGSHIP", 0, 10, getWidth(), 40, juce::Justification::centred);
    }

    void resized() override
    {
        wtSlider.setBounds(350, 200, 200, 40);
    }

private:
    System1AudioProcessor& proc;
    juce::Slider wtSlider;
};
