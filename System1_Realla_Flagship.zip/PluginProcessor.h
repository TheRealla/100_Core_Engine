
#pragma once
#include <JuceHeader.h>
#include "WavetableOsc.h"

class System1AudioProcessor : public juce::AudioProcessor
{
public:
    void prepareToPlay(double sampleRate, int) override
    {
        osc1.prepare(sampleRate);
        osc2.prepare(sampleRate);
    }

    void processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
    {
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            auto* data = buffer.getWritePointer(ch);
            for (int i = 0; i < buffer.getNumSamples(); ++i)
            {
                float s = osc1.process() + osc2.process();
                data[i] = s * 0.2f;
            }
        }
    }

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    WavetableOsc osc1, osc2;
};
