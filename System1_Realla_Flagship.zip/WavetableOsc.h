
#pragma once
#include <vector>
#include <cmath>

class WavetableOsc
{
public:
    void prepare(double sr)
    {
        sampleRate = sr;
        generateTables();
    }

    void setFrequency(float f)
    {
        freq = f;
        updateIncrement();
    }

    void setWTPosition(float pos)
    {
        wtPos = pos * (tables.size() - 1);
    }

    float process()
    {
        int idxA = (int)wtPos;
        int idxB = std::min(idxA + 1, (int)tables.size() - 1);
        float frac = wtPos - idxA;

        float sampleA = tables[idxA][(int)phase];
        float sampleB = tables[idxB][(int)phase];

        float sample = sampleA + frac * (sampleB - sampleA);

        phase += increment;
        if (phase >= tableSize) phase -= tableSize;

        return sample;
    }

private:
    void generateTables()
    {
        tables.resize(32);
        for (int t = 0; t < 32; ++t)
        {
            tables[t].resize(tableSize);
            for (int i = 0; i < tableSize; ++i)
            {
                float x = (float)i / tableSize;
                tables[t][i] = std::sin(2.0f * M_PI * x * (1 + t * 0.2f));
            }
        }
    }

    void updateIncrement()
    {
        increment = (freq * tableSize) / sampleRate;
    }

    std::vector<std::vector<float>> tables;

    int tableSize = 2048;
    float phase = 0;
    float increment = 1;
    float freq = 110;
    float wtPos = 0;
    double sampleRate = 44100;
};
