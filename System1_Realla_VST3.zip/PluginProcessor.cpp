
#include "PluginProcessor.h"
#include "PluginEditor.h"

System1AudioProcessor::System1AudioProcessor() {}
System1AudioProcessor::~System1AudioProcessor() {}

void System1AudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock) {}

void System1AudioProcessor::releaseResources() {}

void System1AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    auto* left = buffer.getWritePointer(0);
    auto* right = buffer.getNumChannels() > 1 ? buffer.getWritePointer(1) : nullptr;

    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        float sample = std::sin(phase);
        phase += 0.03f;

        left[i] = sample;
        if (right) right[i] = sample;
    }
}

juce::AudioProcessorEditor* System1AudioProcessor::createEditor()
{
    return new System1AudioProcessorEditor (*this);
}

bool System1AudioProcessor::hasEditor() const { return true; }
