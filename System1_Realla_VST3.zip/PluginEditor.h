
#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class System1AudioProcessorEditor  : public juce::AudioProcessorEditor
{
public:
    System1AudioProcessorEditor (System1AudioProcessor&);
    ~System1AudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    System1AudioProcessor& audioProcessor;
};
