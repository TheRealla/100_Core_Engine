
#pragma once
#include <JuceHeader.h>

class System1AudioProcessor  : public juce::AudioProcessor
{
public:
    System1AudioProcessor();
    ~System1AudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override { return "System1_Realla"; }

private:
    float phase = 0.0f;
};
