
#include "PluginEditor.h"

System1AudioProcessorEditor::System1AudioProcessorEditor (System1AudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setSize (600, 400);
}

System1AudioProcessorEditor::~System1AudioProcessorEditor() {}

void System1AudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);
    g.setColour (juce::Colours::lime);
    g.setFont (30.0f);
    g.drawText ("System-1 Realla Edition", getLocalBounds(), juce::Justification::centred, true);
}

void System1AudioProcessorEditor::resized() {}
