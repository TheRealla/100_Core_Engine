
#include "PluginEditor.h"

System1AudioProcessorEditor::System1AudioProcessorEditor (System1AudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    addAndMakeVisible(freqKnob);
    addAndMakeVisible(modKnob);

    setSize (700, 500);
}

System1AudioProcessorEditor::~System1AudioProcessorEditor() {}

void System1AudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);

    g.setColour (juce::Colours::lime);
    g.setFont (28.0f);
    g.drawText ("SYSTEM-1 REALLA", 0, 10, getWidth(), 40, juce::Justification::centred);
}

void System1AudioProcessorEditor::resized()
{
    freqKnob.setBounds(150, 150, 120, 120);
    modKnob.setBounds(350, 150, 120, 120);
}
