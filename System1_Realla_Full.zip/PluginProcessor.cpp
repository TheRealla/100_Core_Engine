
#include "PluginProcessor.h"
#include "PluginEditor.h"

System1AudioProcessor::System1AudioProcessor() {}
System1AudioProcessor::~System1AudioProcessor() {}

void System1AudioProcessor::prepareToPlay (double sampleRate, int)
{
    currentSampleRate = sampleRate;
}

float System1AudioProcessor::getNextSample()
{
    float mod = std::sin(phase2) * modAmount;
    float sample = std::sin(phase1 + mod);

    phase1 += (freq / currentSampleRate) * 2.0f * juce::MathConstants<float>::pi;
    phase2 += ((freq * 2) / currentSampleRate) * 2.0f * juce::MathConstants<float>::pi;

    return sample * 0.2f;
}

void System1AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
    {
        auto* data = buffer.getWritePointer(channel);

        for (int i = 0; i < buffer.getNumSamples(); ++i)
        {
            data[i] = getNextSample();
        }
    }
}

juce::AudioProcessorEditor* System1AudioProcessor::createEditor()
{
    return new System1AudioProcessorEditor (*this);
}
