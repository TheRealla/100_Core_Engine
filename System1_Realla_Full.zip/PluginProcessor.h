
#pragma once
#include <JuceHeader.h>

class System1AudioProcessor  : public juce::AudioProcessor
{
public:
    System1AudioProcessor();
    ~System1AudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    float getNextSample();

private:
    double currentSampleRate = 44100.0;

    float phase1 = 0.0f;
    float phase2 = 0.0f;

    float freq = 110.0f;
    float modAmount = 0.5f;
};
