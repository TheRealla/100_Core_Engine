
#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class Knob : public juce::Slider
{
public:
    Knob()
    {
        setSliderStyle(juce::Slider::Rotary);
        setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
    }
};

class System1AudioProcessorEditor  : public juce::AudioProcessorEditor
{
public:
    System1AudioProcessorEditor (System1AudioProcessor&);
    ~System1AudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    System1AudioProcessor& audioProcessor;

    Knob freqKnob;
    Knob modKnob;
};
